import React from 'react'

class Karya extends React.Component {
    render (){
        return (
            <div>
                <h2>Ini karya</h2>
            </div>
        )
    }
}

export default Karya;