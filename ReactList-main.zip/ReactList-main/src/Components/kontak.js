import React from 'react'

class Kontak extends React.Component {
    render(){
        return(
            <div>
                <h2>Ini Kontak</h2>
            </div>
        )
    }
}

export default Kontak;