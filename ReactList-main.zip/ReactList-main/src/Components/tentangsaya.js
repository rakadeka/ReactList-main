import React from 'react';

class Tentangsaya extends React.Component {
    render(){
        return (
            <div>
            <h2>Ini tentang saya</h2>
            </div>
        )
    }
}

export default Tentangsaya;